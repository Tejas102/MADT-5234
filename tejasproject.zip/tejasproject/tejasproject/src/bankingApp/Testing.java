package bankingApp;

import static org.junit.Assert.*;

import org.junit.Test;

public class Testing {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
