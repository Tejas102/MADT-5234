package bankingApp;

public class Customer {
	
	public Customer(String name, int initialDeposit) {
		this.name = name;
		if (initialDeposit > 0) {
			this.account = new Account(name, null, initialDeposit);
		}
	}
	
	/**
	 * Get the account
	 * @return The customer's account
	 */
	public Account getAccount() {
		return this.account;
	}
	
	public String getName() {
		return name;
	}
	
	
	// instance variables
	
	private String name;
	private Account account = null;

}
