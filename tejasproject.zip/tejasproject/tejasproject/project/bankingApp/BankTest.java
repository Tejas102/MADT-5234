package bankingApp;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import bankingApp.AccountDoesNotExistException;
import bankingApp.AccountExistsException;
import bankingApp.Bank;
import bankingApp.Currency;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class BankTest {
	
	public BankTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getCustomers method, of class Bank.
     */
    @Test
    public void testBank() {
        System.out.println("Test Bank");
        Bank instance = new Bank(null, null);
        int expResult = 0;
        // checking number of customers
        // EXPECTED OUTPUT 0
        int result = instance.getNumberOfCustomers();
        assertEquals(expResult, result);
    }

    @Test
    public void testGetCustomers() {
        System.out.println("getCustomers");
        Bank instance = new Bank(null, null);
        /* 
            ADDING CUSTOMERS
        */
        instance.addCustomer("Akashdeep", 100);
        instance.addCustomer("Abhishek", 200);

        ArrayList<Customer> expResult = instance.getCustomers();
        ArrayList<Customer> result = instance.getCustomers();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of addCustomer method, of class Bank.
     */
    @Test
    public void testAddCustomer() {
        System.out.println("addCustomer");
        //String name = "";
        Bank instance = new Bank(null, null);
        int expResult = 1;
        /*
        ADDING FIRST CUSTOMER
         */
        instance.addCustomer("Akashdeep", 100);
        int result = instance.getNumberOfCustomers();
        System.out.println("No of Customers : " + result);
        assertEquals(expResult, result);

        /*
        ADDING SECOND CUSTOMER TO TEST REQUIREMENT 2
         */
        instance.addCustomer("Abhishek", 200);
        expResult = 2;
        result = instance.getNumberOfCustomers();
        System.out.println("No of Customers : " + result);
        assertEquals(expResult, result);

    }

    /**
     * Test of removeCustomer method, of class Bank.
     */
    @Test
    public void testRemoveCustomer() {
        System.out.println("removeCustomer");
        String name = "Akashdeep";
        Bank instance = new Bank(name, null);
        instance.addCustomer(name, 200);
        boolean expResult = true;
        System.out.println("No of Customers before removing : " + instance.getNumberOfCustomers());

        boolean result = instance.removeCustomer(name);
        assertEquals(expResult, result);
        System.out.println("No of Customers after removing : " + instance.getNumberOfCustomers());

    }

    /**
     * Test of getNumberOfCustomers method, of class Bank.
     */
    @Test
    public void testGetNumberOfCustomers() {
        System.out.println("getNumberOfCustomers");
        Bank instance = new Bank(null, null);
        instance.addCustomer("Abhishek", 200);

        int expResult = 1;
        int result = instance.getNumberOfCustomers();
        assertEquals(expResult, result);
    }

    /**
     * Test of transferMoney method, of class Bank.
     */
    @Test
    public void testTransferMoney() {
        System.out.println("transferMoney");
        Bank instance = new Bank(null, null);
        instance.addCustomer("Abhishek", 200);
        instance.addCustomer("Akash", 100);
        

        Customer fromCustomer = new Customer("Abhishek",200);
        Customer toCustomer = new Customer("Akashdeep", 100);
        int amountToTransfer = 10;
        boolean expResult = true;
        boolean result = instance.transferMoney(fromCustomer, toCustomer, amountToTransfer);
        assertEquals(expResult, result);
        System.out.println("Customer 1 Balance "+fromCustomer.getAccount().balance());
        System.out.println("Customer 2 Balance "+toCustomer.getAccount().balance());
    }
	
	
//	protected Currency CAD;
//	protected Currency HKD;
//	protected Bank RBC;
//	protected Bank TD;
//	protected Bank HSBC;
//	
//	
//	@Before
//	public void setUp() throws Exception {
//		
//		// setup some test currencies
//		this.HKD = new Currency("HKD", 0.13);
//		this.CAD = new Currency("CAD", 0.75);
//		
//		// setup test banks
//		this.RBC = new Bank("Royal Bank of Canada", CAD);
//		this.TD = new Bank("TD Bank", CAD);
//		this.HSBC = new Bank("Hong Kong Shanghai Banking Corporation", HKD);
//		
//		// add sample customers to the banks
//		
//		
//		// HINT:  uncomment these lines AFTER you test the openAccount() function
//		// You can quickly uncomment / comment by highlighting the lines of code and pressing 
//		// CTRL + / on your keyboard  (or CMD + / for Macs)
//		
////		this.RBC.openAccount("Marcos");
////		this.RBC.openAccount("Albert");
////		this.TD.openAccount("Jigesha");
////		this.HSBC.openAccount("Pritesh");
//	}
//
//	@Test
//	public void testGetName() {
//		fail("Write test case here");
//	}
//
//	@Test
//	public void testGetCurrency() {
//		fail("Write test case here");
//	}
//
//	@Test
//	public void testOpenAccount() throws AccountExistsException, AccountDoesNotExistException {
//		// If the function throws an exception, you should also test
//		// that the exception gets called properly.
//		
//		// See the example in class notes for testing exceptions.
//		
//		fail("Write test case here");
//	}
//
//	@Test
//	public void testDeposit() throws AccountDoesNotExistException {
//		// If the function throws an exception, you should also test
//		// that the exception gets called properly.
//		
//		// See the example in class notes for testing exceptions.
//		
//		fail("Write test case here");
//	}
//
//	@Test
//	public void testWithdraw() throws AccountDoesNotExistException {
//		// If the function throws an exception, you should also test
//		// that the exception gets called properly.
//		
//		// See the example in class notes for testing exceptions.
//		
//		fail("Write test case here");
//	}
//	
//	@Test
//	public void testGetBalance() throws AccountDoesNotExistException {
//		// If the function throws an exception, you should also test
//		// that the exception gets called properly.
//		
//		// See the example in class notes for testing exceptions.
//		
//		fail("Write test case here");
//	}
//	
//	@Test
//	public void testTransfer() throws AccountDoesNotExistException {
//		// Note: You should test both types of transfers:
//		// 1. Transfer from account to account
//		// 2. Transfer between banks
//		// See the Bank.java file for more details on Transfers
//		fail("Write test case here");
//	}
	
}
